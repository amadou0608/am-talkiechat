# Talkie Chat — Phase 18

## Finitions de messagerie

Implemented:
- read receipts: `sent` → `delivered` → `read`
- automatic read marking when a conversation is opened or receives a message while open
- real-time `message:status` updates for read receipts
- typing indicator with Socket.IO (`typing:start` / `typing:stop`)
- conversation summaries on the home screen
- last-message preview and timestamp
- unread-message badge/count per conversation
- text-message editing with `edited_at` and a visible “modifié” indicator
- deletion for everyone for sent messages (soft-delete in PostgreSQL)
- real-time message update/deletion events
- new database index for unread messages
- migration `007_phase18_message_state.sql`

The implementation follows the Phase 18 requirements in the Talkie Chat cahier des charges: read receipts, typing indicator, last-message preview on the home screen, and message modification/deletion. The existing Phase 13 schema already contained `edited_at` and `deleted_at`; Phase 18 adds the operational API/UI and unread index.
