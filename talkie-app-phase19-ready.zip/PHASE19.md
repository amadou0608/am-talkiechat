# Phase 19 — Tests et préparation du déploiement

## Périmètre
Cette phase clôt le développement prévu par le cahier des charges Talkie Chat : contrôle statique du projet, vérification de la structure des migrations, contrôle des routes média/messagerie et préparation du déploiement.

## Contrôles effectués

- [x] Archive source extraite et structure vérifiée.
- [x] Migrations PostgreSQL présentes dans l'ordre 001 → 007.
- [x] Table `messages` et migration d'état de Phase 18 présentes.
- [x] Routes texte, vocal, image, vidéo, lecture, délivré, modification et suppression présentes.
- [x] Limite vidéo de 5 minutes documentée dans la Phase 17.
- [x] Les anciens fichiers source PTT/WebRTC supprimés ne sont plus présents dans l'arborescence.
- [x] Aucun fichier `PTTButton.tsx`, `useWebRTCCall.ts`, `webrtcConfig.ts` ou `webrtc.signaling.ts` n'est présent.
- [x] Archive ZIP finale vérifiée après génération.

## Validation locale

L'environnement de génération ne contient pas les dépendances `node_modules` du frontend et du backend. Une installation npm a été tentée mais n'a pas terminé dans le délai disponible. Par conséquent, le build TypeScript/Vite et les tests Vitest ne sont pas déclarés comme réussis ici.

À exécuter après récupération du ZIP :

```bash
cd backend
npm ci
npm test
npm run build
npm run migrate

cd ../talkie-app
npm ci
npm test
npm run build
```

## Checklist de recette avant production

- [ ] Créer deux comptes de test.
- [ ] Accepter la relation de contact.
- [ ] Tester texte : envoi, réception, historique.
- [ ] Tester ✓ / ✓✓ / lu sur deux appareils.
- [ ] Tester « en train d'écrire… ».
- [ ] Tester modification et suppression pour tout le monde.
- [ ] Tester vocal et lecture inline.
- [ ] Tester photo : galerie, caméra, aperçu, envoi et plein écran.
- [ ] Tester vidéo : aperçu, envoi et lecture ; refuser une vidéo > 5 min.
- [ ] Vérifier l'accès privé aux médias d'un autre utilisateur.
- [ ] Vérifier les messages non lus et le dernier message sur l'accueil.
- [ ] Vérifier le stockage persistant après redéploiement.
- [ ] Vérifier la purge des données/fichiers après la période configurée.
- [ ] Vérifier HTTPS, CORS, cookies, WebSocket sécurisé et notifications push.

## Déploiement recommandé

Le frontend est un build Vite statique et peut être déployé sur Vercel/Netlify/CDN. Le backend Node.js + Socket.IO doit rester sur un service persistant (Railway, Render, Fly.io ou VPS). PostgreSQL doit être managé ou hébergé avec sauvegardes.

Le stockage des médias doit utiliser un volume persistant monté dans le backend. Le système PTT/WebRTC ayant été retiré, aucune configuration TURN/STUN n'est requise pour Talkie Chat.
