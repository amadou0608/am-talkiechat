# Déploiement — Talkie Chat, Phase 19

Ce guide correspond à la version finale issue des phases 13 à 19. Talkie est désormais une messagerie texte, vocale, photo et vidéo. Le système PTT/WebRTC a été retiré : **aucun serveur TURN/STUN n'est nécessaire** pour cette version.

## 1. Architecture

| Brique | Nature | Déploiement conseillé |
|---|---|---|
| `talkie-app/` | frontend React/Vite/PWA | Vercel, Netlify ou CDN |
| `backend/` | API Node.js + Socket.IO | Railway, Render, Fly.io ou VPS |
| PostgreSQL | base de données | service PostgreSQL managé ou VPS |
| `/app/uploads` | médias persistants | volume persistant attaché au backend |

## 2. Frontend

Dans `talkie-app/` :

```bash
npm ci
npm test
npm run build
```

Variables de production :

```env
VITE_API_URL=https://api.talkie.exemple.com
VITE_WS_URL=wss://api.talkie.exemple.com
```

Déployer le contenu de `talkie-app/dist/` sur le fournisseur choisi. Le domaine doit être servi en HTTPS.

## 3. Backend

Dans `backend/` :

```bash
npm ci
npm test
npm run build
npm run migrate
npm start
```

Variables principales :

```env
DATABASE_URL=postgresql://...
JWT_SECRET=<secret-fort>
JWT_EXPIRES_IN=7d
PORT=4000
NODE_ENV=production
CORS_ORIGIN=https://talkie.exemple.com
WEB_PUSH_PUBLIC_KEY=...
WEB_PUSH_PRIVATE_KEY=...
WEB_PUSH_CONTACT_EMAIL=mailto:contact@talkie.exemple.com
```

`CORS_ORIGIN` doit correspondre exactement à l'origine publique du frontend.

## 4. Stockage des médias

Les photos, vidéos et vocaux doivent être placés sur un **volume persistant**. Le chemin utilisé par le backend doit survivre aux redéploiements.

Avant production :

- définir une limite d'upload adaptée au plan de stockage ;
- vérifier les droits d'écriture du volume ;
- vérifier que les routes média contrôlent l'identité de l'utilisateur ;
- prévoir sauvegardes/monitoring ;
- conserver la purge automatique prévue après 6 mois.

## 5. Base de données

Les migrations doivent être exécutées dans l'ordre :

```text
001_create_users.sql
002_create_contacts.sql
003_create_voice_messages.sql
004_create_devices.sql
005_create_messages.sql
006_messages_voice_mime.sql
007_phase18_message_state.sql
```

Ne pas supprimer les anciennes migrations déjà appliquées en production.

## 6. WebSocket

Le frontend de production doit utiliser `wss://` lorsque le site est servi en HTTPS. Socket.IO est utilisé pour les messages temps réel, la présence, les accusés de lecture et l'indicateur de saisie.

## 7. Notifications push

Configurer les trois variables Web Push côté backend, puis vérifier l'autorisation navigateur sur Android/Chrome. Tester une notification avec le destinataire hors ligne.

## 8. Checklist finale

- [ ] PostgreSQL provisionné et sauvegardes activées.
- [ ] Toutes les migrations appliquées.
- [ ] Volume persistant monté.
- [ ] Variables d'environnement renseignées.
- [ ] Backend accessible en HTTPS.
- [ ] WebSocket `wss://` fonctionnel.
- [ ] Frontend construit avec `npm run build`.
- [ ] Deux comptes de test créés.
- [ ] Texte, vocal, photo et vidéo testés.
- [ ] Vidéo > 5 minutes refusée.
- [ ] ✓ / ✓✓ / lu vérifiés.
- [ ] « en train d'écrire… » vérifié.
- [ ] Modification/suppression vérifiées.
- [ ] Non-lus et aperçu du dernier message vérifiés.
- [ ] Accès privé aux médias vérifié.
- [ ] Persistance des fichiers vérifiée après redéploiement.
- [ ] Purge des anciennes données/fichiers vérifiée.

## 9. Limitation de cette livraison

Le ZIP a été contrôlé statiquement et son archive est vérifiable, mais les dépendances npm ne sont pas incluses. L'environnement de génération n'a pas permis de terminer `npm ci`; le build complet et les tests Vitest doivent donc être exécutés sur la machine ou le service de déploiement avec accès npm.
