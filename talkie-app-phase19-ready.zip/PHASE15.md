
# Phase 15 — messages vocaux dans le fil

- Ajout de `POST /messages/voice` pour envoyer un vocal directement dans la table `messages` avec `type=voice`.
- Ajout de `GET /messages/:messageId/voice` avec contrôle d'accès et support HTTP Range.
- Réutilisation de `useVoiceRecorder` et du stockage audio existant.
- Conservation des anciennes routes `/voice-messages` pour compatibilité avec les données historiques.
- Ajout de `mime_type` à `messages` pour servir correctement les nouveaux fichiers audio.
