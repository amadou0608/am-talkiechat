# Talkie Chat — Phase 17

## Vidéos

Implemented:
- video selection from the gallery
- direct mobile camera capture through a dedicated video input
- mandatory local metadata check before upload
- hard client-side duration limit of 5 minutes
- 60 MB upload guard on client and server
- preview before sending with native video controls
- authenticated multipart upload through `POST /messages/video`
- server-side MIME, size and declared-duration validation
- private video streaming through `GET /messages/:messageId/video`
- HTTP Range support for seeking/progressive playback
- `duration_sec` persistence for video messages
- real-time `message:new` delivery and offline push notification
- video playback inline in the conversation

The 5-minute maximum follows the decision recorded in the 26/08/2026 cahier des charges. The browser uses the device/native video encoding for captured videos; no server-side transcoding dependency was added in this phase.
