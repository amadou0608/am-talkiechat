# Talkie Chat — Phase 16

## Photos

Implemented:
- gallery selection and mobile camera capture
- client-side resize/compression to JPEG (max 1920 px, quality 0.82)
- mandatory preview before upload
- authenticated multipart upload through `POST /messages/image`
- server-side MIME and 12 MB validation
- private image streaming through `GET /messages/:messageId/image`
- image thumbnails in the conversation
- full-screen lightbox on click
- real-time `message:new` delivery and offline push notification
- `mime_type` reuse from Phase 15 for image metadata

The source file remains private; no public static directory is exposed.
